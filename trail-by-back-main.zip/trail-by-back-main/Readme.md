Все по умолчанию работает на 4000 порте.

Добавление комментария - 
http://{domain}/comment?name={Nickname}&email={user mail}&text={commentariy text}&rating={count of stars}&id={news id}

Список комментария к новости/видео - http://{domain}/comments?id={news id}

Список всех новостей - http://{domain}/news

Список новостей по фильтрам - http://{domain}/news?filter={filter name}

Список видео обзоров - http://{domain}/videos

Добавление видео обзора - http://{domain}/video?caption={video caption}&url={video url}

Получения списка мест по фильтрам - http://localhost:4000/filter?filter={filter text}